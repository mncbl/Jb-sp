package jbsp_4;

public class main {
	public static void main(String[] args) {

	double SP;
	double RJ;
	double MG;
	double ES;
	double Outros;
	
	 
	
		SP = 67836.43;
		RJ = 36678.66;
		MG = 29229.88;
		ES = 27165.48;
		Outros = 19849.53;
		double Soma = (SP + RJ + MG + ES+ Outros);
		System.out.print(Soma);
		double psp = ((SP/Soma)*100);
		System.out.println(psp+"%");
		double prj = ((RJ/Soma)*100);
		System.out.println(prj+"%");
		double pmg = ((MG/Soma)*100);
		System.out.println(pmg+"%");
		double pes = ((ES/Soma)*100);
		System.out.println(pes+"%");
		double pout = ((Outros/Soma)*100);
		System.out.println(pout+"%");
		
		
		
		
}
}