package Exec5;

public class contra {
	public static void main(String[] args) {
    String palavra = "arara";
    String inverso = "";

    System.out.print("A Palavra: " +palavra);
    inverso = new StringBuffer(palavra).reverse().toString();
    if (palavra.equals(inverso)) {
    System.out.println("  é palíndromo");
    } else {
    System.out.println(" Não é Palíndromo");
    }

}

}
